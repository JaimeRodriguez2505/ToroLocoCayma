export function getBackendBaseUrl() {
  return process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:3000";
}

export function toAbsoluteUrl(pathOrUrl: string | null) {
  if (!pathOrUrl) return null;
  if (pathOrUrl.startsWith("http://") || pathOrUrl.startsWith("https://")) {
    return normalizeLocalhostProtocol(pathOrUrl);
  }
  const base = getBackendBaseUrl().replace(/\/$/, "");
  const path = pathOrUrl.startsWith("/") ? pathOrUrl : `/${pathOrUrl}`;
  return `${base}${path}`;
}

export function normalizeLocalhostProtocol(url: string) {
  try {
    const u = new URL(url);
    if (
      (u.hostname === "localhost" || u.hostname === "127.0.0.1") &&
      u.protocol === "https:"
    ) {
      u.protocol = "http:";
      return u.toString();
    }
    return url;
  } catch {
    return url;
  }
}

export function toWhatsappLink(raw: string | null) {
  if (!raw) return null;
  const digits = raw.replace(/[^\d]/g, "");
  if (!digits) return null;
  return `https://wa.me/${digits}`;
}

