import Script from "next/script";
import Catalog from "@/components/Catalog";
import Hero from "@/components/Hero";
import LibroReclamacionesForm from "@/components/LibroReclamacionesForm";
import PromoGrid from "@/components/PromoGrid";
import {
  getEcommerceBanner,
  getEcommerceBanners,
  getEcommerceCategories,
  getEcommerceOffers,
  getEcommerceProducts,
  getEcommerceTarjetas,
} from "@/lib/toroApi";

export default async function Home() {
  const [banner, banners, tarjetas, categorias, productos, ofertas] =
    await Promise.all([
      getEcommerceBanner(),
      getEcommerceBanners(),
      getEcommerceTarjetas(),
      getEcommerceCategories(),
      getEcommerceProducts(),
      getEcommerceOffers(),
    ]);

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <Script
        id="ld-json-localbusiness"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Restaurant",
            name: "Toro Loco Cayma",
            servesCuisine: ["Parrillas", "Carnes", "Cócteles"],
            areaServed: "Cayma, Arequipa",
            url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3033",
          }),
        }}
      />

      <Hero banner={banner} />

      <PromoGrid banners={banners} tarjetas={tarjetas} />

      <Catalog categorias={categorias} productos={productos} ofertas={ofertas} />

      <LibroReclamacionesForm />
    </main>
  );
}
