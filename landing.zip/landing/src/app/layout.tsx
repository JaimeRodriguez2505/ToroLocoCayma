import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Footer from "@/components/Footer";
import Header from "@/components/Header";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3033"),
  title: {
    default: "Toro Loco Cayma | Parrillas y Cócteles",
    template: "%s | Toro Loco Cayma",
  },
  description:
    "Parrillería Toro Loco Cayma: parrillas, carnes, cócteles y promociones. Revisa nuestra carta y envíanos tu reclamo si lo necesitas.",
  keywords: [
    "Toro Loco Cayma",
    "parrillería",
    "parrillas",
    "carnes a la parrilla",
    "cócteles",
    "Arequipa",
    "Cayma",
  ],
  openGraph: {
    type: "website",
    title: "Toro Loco Cayma | Parrillas y Cócteles",
    description:
      "Parrillería Toro Loco Cayma: parrillas, carnes, cócteles y promociones.",
    siteName: "Toro Loco Cayma",
    locale: "es_PE",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-dvh bg-white text-zinc-900`}
      >
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
