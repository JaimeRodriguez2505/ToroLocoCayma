export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <a href="#" className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-zinc-900" />
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-tight">Toro Loco</div>
            <div className="text-xs text-zinc-600">Cayma</div>
          </div>
        </a>

        <nav className="hidden items-center gap-6 text-sm text-zinc-700 sm:flex">
          <a className="hover:text-zinc-900" href="#promos">
            Promos
          </a>
          <a className="hover:text-zinc-900" href="#carta">
            Carta
          </a>
          <a className="hover:text-zinc-900" href="#reclamaciones">
            Reclamaciones
          </a>
        </nav>

        <a
          className="inline-flex h-10 items-center justify-center rounded-full bg-zinc-900 px-4 text-sm font-medium text-white hover:bg-zinc-800"
          href="#carta"
        >
          Ver carta
        </a>
      </div>
    </header>
  );
}

