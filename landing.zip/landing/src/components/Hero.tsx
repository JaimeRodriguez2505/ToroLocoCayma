import Image from "next/image";
import type { EcommerceBanner } from "@/lib/types";
import { toWhatsappLink } from "@/lib/url";

type Props = {
  banner: EcommerceBanner | null;
};

export default function Hero({ banner }: Props) {
  const whatsappHref = toWhatsappLink(banner?.whatsapp ?? null);

  return (
    <section className="grid gap-8 py-10 lg:grid-cols-2 lg:items-center">
      <div>
        <p className="text-sm font-medium text-zinc-700">
          Parrillería · Cayma, Arequipa
        </p>
        <h1 className="mt-3 text-4xl font-semibold tracking-tight text-zinc-900 sm:text-5xl">
          Toro Loco Cayma
        </h1>
        <p className="mt-4 text-base leading-7 text-zinc-600 sm:text-lg">
          Parrillas al punto, cortes jugosos y cócteles clásicos. Descubre la
          carta y aprovecha nuestras promociones y ofertas del día.
        </p>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <a
            className="inline-flex h-11 items-center justify-center rounded-full bg-zinc-900 px-5 text-sm font-medium text-white hover:bg-zinc-800"
            href="#carta"
          >
            Ver carta
          </a>
          {whatsappHref ? (
            <a
              className="inline-flex h-11 items-center justify-center rounded-full border border-zinc-300 px-5 text-sm font-medium text-zinc-900 hover:bg-zinc-50"
              href={whatsappHref}
              target="_blank"
              rel="noreferrer"
            >
              WhatsApp
            </a>
          ) : null}
        </div>
      </div>

      <div className="relative overflow-hidden rounded-3xl border border-zinc-200 bg-zinc-100">
        {banner?.imagen_url ? (
          <Image
            src={banner.imagen_url}
            alt="Banner Toro Loco Cayma"
            width={1200}
            height={800}
            className="h-[320px] w-full object-cover sm:h-[420px]"
            priority
          />
        ) : (
          <div className="flex h-[320px] items-center justify-center sm:h-[420px]">
            <div className="text-sm text-zinc-600">Banner no disponible</div>
          </div>
        )}
      </div>
    </section>
  );
}

