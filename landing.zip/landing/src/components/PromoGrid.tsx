import Image from "next/image";
import type { EcommerceBanner, EcommerceTarjeta } from "@/lib/types";

type Props = {
  banners: EcommerceBanner[];
  tarjetas: EcommerceTarjeta[];
};

export default function PromoGrid({ banners, tarjetas }: Props) {
  return (
    <section id="promos" className="py-10">
      <div className="flex items-end justify-between gap-6">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Promociones</h2>
          <p className="mt-2 text-sm leading-6 text-zinc-600">
            Ofertas, anuncios y beneficios pensados para tu parrillada.
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <div className="grid gap-4 sm:grid-cols-2">
            {tarjetas.slice(0, 4).map((t) => (
              <div
                key={t.id_tarjeta}
                className="rounded-2xl border border-zinc-200 bg-white p-5"
              >
                {t.imagen_url ? (
                  <Image
                    src={t.imagen_url}
                    alt={t.titulo}
                    width={800}
                    height={600}
                    className="h-40 w-full rounded-xl object-cover"
                  />
                ) : (
                  <div className="h-40 w-full rounded-xl bg-zinc-100" />
                )}
                <div className="mt-4 text-base font-semibold">{t.titulo}</div>
                {t.descripcion ? (
                  <div className="mt-1 text-sm leading-6 text-zinc-600">
                    {t.descripcion}
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="grid gap-4">
            {banners.slice(0, 2).map((b) => (
              <div
                key={b.id_banner}
                className="overflow-hidden rounded-2xl border border-zinc-200 bg-white"
              >
                {b.imagen_url ? (
                  <Image
                    src={b.imagen_url}
                    alt="Banner"
                    width={1200}
                    height={800}
                    className="h-52 w-full object-cover"
                  />
                ) : (
                  <div className="h-52 w-full bg-zinc-100" />
                )}
                <div className="px-5 py-4 text-sm text-zinc-600">
                  Promoción destacada
                </div>
              </div>
            ))}
            {banners.length === 0 && tarjetas.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-zinc-300 p-8 text-center text-sm text-zinc-600">
                Aún no hay promociones publicadas.
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}

