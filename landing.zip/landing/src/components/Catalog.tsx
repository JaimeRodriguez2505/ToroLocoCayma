"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import type {
  EcommerceCategory,
  EcommerceProduct,
  EcommerceProductOffer,
} from "@/lib/types";

type Props = {
  categorias: EcommerceCategory[];
  productos: EcommerceProduct[];
  ofertas: EcommerceProductOffer[];
};

type CategoriaSeleccion = number | "all";

function formatPrice(value: string | number | null | undefined) {
  const n =
    typeof value === "string" ? Number.parseFloat(value) : value ?? undefined;
  if (n === undefined || Number.isNaN(n)) return null;
  return `S/ ${n.toFixed(2)}`;
}

function getProductPrice(p: EcommerceProduct | EcommerceProductOffer) {
  const offer = formatPrice(p.precio_oferta ?? null);
  const normal = formatPrice(p.precio ?? null);
  return { offer, normal };
}

export default function Catalog({ categorias, productos, ofertas }: Props) {
  const [categoriaSeleccionada, setCategoriaSeleccionada] =
    useState<CategoriaSeleccion>("all");
  const [soloOfertas, setSoloOfertas] = useState(false);
  const [query, setQuery] = useState("");

  const ofertasIds = useMemo(() => {
    return new Set(ofertas.map((o) => o.id_producto));
  }, [ofertas]);

  const categoriasSorted = useMemo(() => {
    return [...categorias].sort((a, b) => a.nombre.localeCompare(b.nombre));
  }, [categorias]);

  const productosFiltrados = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return productos
      .filter((p) => {
        if (categoriaSeleccionada === "all") return true;
        return p.id_categoria === categoriaSeleccionada;
      })
      .filter((p) => {
        if (!soloOfertas) return true;
        return p.es_oferta || ofertasIds.has(p.id_producto);
      })
      .filter((p) => {
        if (!normalizedQuery) return true;
        const haystack = `${p.nombre} ${p.descripcion ?? ""}`.toLowerCase();
        return haystack.includes(normalizedQuery);
      })
      .sort((a, b) => a.nombre.localeCompare(b.nombre));
  }, [productos, categoriaSeleccionada, soloOfertas, query, ofertasIds]);

  const headerStats = useMemo(() => {
    const totalProductos = productos.length;
    const totalOfertas = ofertas.length;
    return { totalProductos, totalOfertas };
  }, [productos.length, ofertas.length]);

  return (
    <section id="carta" className="py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Carta</h2>
          <p className="mt-2 text-sm leading-6 text-zinc-600">
            {headerStats.totalProductos} productos · {headerStats.totalOfertas}{" "}
            ofertas
          </p>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar en la carta…"
              className="h-11 w-full rounded-full border border-zinc-300 bg-white px-4 text-sm outline-none ring-zinc-900 focus:ring-2 sm:w-72"
            />
          </div>

          <button
            type="button"
            onClick={() => setSoloOfertas((v) => !v)}
            className={[
              "h-11 rounded-full px-5 text-sm font-medium",
              soloOfertas
                ? "bg-zinc-900 text-white"
                : "border border-zinc-300 bg-white text-zinc-900 hover:bg-zinc-50",
            ].join(" ")}
          >
            {soloOfertas ? "Mostrando ofertas" : "Solo ofertas"}
          </button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setCategoriaSeleccionada("all")}
          className={[
            "h-9 rounded-full px-4 text-sm",
            categoriaSeleccionada === "all"
              ? "bg-zinc-900 text-white"
              : "border border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-50",
          ].join(" ")}
        >
          Todas
        </button>
        {categoriasSorted.map((c) => (
          <button
            key={c.id_categoria}
            type="button"
            onClick={() => setCategoriaSeleccionada(c.id_categoria)}
            className={[
              "h-9 rounded-full px-4 text-sm",
              categoriaSeleccionada === c.id_categoria
                ? "bg-zinc-900 text-white"
                : "border border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-50",
            ].join(" ")}
          >
            {c.nombre}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {productosFiltrados.map((p) => {
          const { offer, normal } = getProductPrice(p);
          const showOffer = Boolean(p.es_oferta && offer);

          return (
            <article
              key={p.id_producto}
              className="overflow-hidden rounded-2xl border border-zinc-200 bg-white"
            >
              <div className="relative">
                {p.imagen_url ? (
                  <Image
                    src={p.imagen_url}
                    alt={p.nombre}
                    width={900}
                    height={700}
                    className="h-44 w-full object-cover"
                  />
                ) : (
                  <div className="h-44 w-full bg-zinc-100" />
                )}
                {p.es_oferta ? (
                  <div className="absolute left-3 top-3 rounded-full bg-zinc-900 px-3 py-1 text-xs font-medium text-white">
                    Oferta
                  </div>
                ) : null}
              </div>

              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold leading-6">
                      {p.nombre}
                    </h3>
                    <div className="mt-1 text-xs text-zinc-500">
                      {p.categoria?.nombre ?? "Sin categoría"}
                    </div>
                  </div>

                  <div className="text-right">
                    {showOffer ? (
                      <>
                        <div className="text-sm font-semibold text-zinc-900">
                          {offer}
                        </div>
                        {normal ? (
                          <div className="text-xs text-zinc-500 line-through">
                            {normal}
                          </div>
                        ) : null}
                      </>
                    ) : (
                      <div className="text-sm font-semibold text-zinc-900">
                        {normal ?? "—"}
                      </div>
                    )}
                  </div>
                </div>

                {p.descripcion ? (
                  <p className="mt-3 line-clamp-3 text-sm leading-6 text-zinc-600">
                    {p.descripcion}
                  </p>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>

      {productosFiltrados.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-zinc-300 p-10 text-center text-sm text-zinc-600">
          No se encontraron productos con estos filtros.
        </div>
      ) : null}
    </section>
  );
}

