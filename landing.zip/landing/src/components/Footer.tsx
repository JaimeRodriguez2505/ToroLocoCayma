export default function Footer() {
  return (
    <footer className="border-t border-zinc-200 bg-white">
      <div className="mx-auto w-full max-w-6xl px-4 py-10 text-sm text-zinc-600 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-zinc-800">
            <span className="font-medium">Toro Loco Cayma</span>{" "}
            <span className="text-zinc-500">·</span>{" "}
            <span className="text-zinc-600">Parrillería</span>
          </div>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            <a className="hover:text-zinc-900" href="#promos">
              Promos
            </a>
            <a className="hover:text-zinc-900" href="#carta">
              Carta
            </a>
            <a className="hover:text-zinc-900" href="#reclamaciones">
              Libro de reclamaciones
            </a>
          </div>
        </div>
        <div className="mt-6 text-xs text-zinc-500">
          © {new Date().getFullYear()} Toro Loco Cayma. Todos los derechos
          reservados.
        </div>
      </div>
    </footer>
  );
}

